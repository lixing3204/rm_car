/* This file provides the bit-probabilities for the input file */
#define BIT_DIVIDER 629 
static int bits[9] = { 179,167,183,165,159,198,178,119,}; /* ia32 .so files */
